<?php echo $__env->make('admin.page.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <body>

    <!-- ########## START: LEFT PANEL ########## -->
   <?php echo $__env->make('admin.page.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <!-- ########## START: HEAD PANEL ########## -->
   <?php echo $__env->make('admin.page.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- ########## END: RIGHT PANEL ########## --->

    <!-- ########## START: MAIN PANEL ########## -->
	    <div class="sl-mainpanel">
         <nav class="breadcrumb sl-breadcrumb">
        <a class="breadcrumb-item" href="index.html">Dashboard</a>
        <span class="breadcrumb-item active">Site Settings</span>
      </nav>
	   
	  
	   <div class="sl-pagebody">
	   <div class="sl-page-title">
	 
	    <div class="card pd-20 pd-sm-40">
          <h6 class="card-body-title">Site Settings</h6>
            <form action="<?php echo e(route('admin.update.site')); ?>" method="post">
         <?php echo csrf_field(); ?>
		 <div class="form-layout">
            <div class="row mg-b-25">
			<input type="hidden" name="id" value="<?php echo e($data->id); ?>" />
              <div class="col-lg-6">
                <div class="form-group">
                  <label class="form-control-label">Site Title</label>
                  <input class="form-control" type="text" name="title" value="<?php echo e($data->site_title); ?>">
                </div>
              </div><!-- col-4 -->
              <div class="col-lg-6">
                <div class="form-group">
                  <label class="form-control-label">Hotline</label>
                  <input class="form-control" type="text" name="hotline" value="<?php echo e($data->hotline); ?>">
                </div>
              </div><!-- col-4 -->
              <div class="col-lg-6">
                <div class="form-group">
                  <label class="form-control-label">Address</label>
                  <input class="form-control" type="text" name="address" value="<?php echo e($data->address); ?>">
                </div>
              </div><!-- col-4 -->
			  <div class="col-lg-6">
                <div class="form-group">
                  <label class="form-control-label">Email</label>
                  <input class="form-control" type="text" name="email" value="<?php echo e($data->email); ?>">
                </div>
              </div><!-- col-4 -->
			  <div class="col-lg-6">
                <div class="form-group">
                  <label class="form-control-label">Facebook ID</label>
                  <input class="form-control" type="text" name="facebook" value="<?php echo e($data->facebook_id); ?>">
                </div>
              </div><!-- col-4 -->
			  	  <div class="col-lg-6">
                <div class="form-group">
                  <label class="form-control-label">Gmail ID</label>
                  <input class="form-control" type="text" name="gmail" value="<?php echo e($data->gmail_id); ?>">
                </div>
              </div><!-- col-4 -->
              
            
			 
			 
			 
           
			
			
			
			   </div><!-- row -->
			  <input type="submit" class="btn btn-primary" value="Submit" />
	  
	 </form>
	  
	  
	  
	  
	  
	  
	  
	  </div>
	  </div>
	  </div>
	 
 
 
 
	     <?php echo $__env->make('admin.page.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 <?php /**PATH C:\xampp\htdocs\grocery_ecommerce\resources\views/admin/siteshow.blade.php ENDPATH**/ ?>