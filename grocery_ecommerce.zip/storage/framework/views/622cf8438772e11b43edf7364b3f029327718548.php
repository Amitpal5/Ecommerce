<?php echo $__env->make('admin.page.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <body>

    <!-- ########## START: LEFT PANEL ########## -->
   <?php echo $__env->make('admin.page.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <!-- ########## START: HEAD PANEL ########## -->
   <?php echo $__env->make('admin.page.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- ########## END: RIGHT PANEL ########## --->

    <!-- ########## START: MAIN PANEL ########## -->
	    <div class="sl-mainpanel">
         <nav class="breadcrumb sl-breadcrumb">
        <a class="breadcrumb-item" href="index.html">Dashboard</a>
        <span class="breadcrumb-item active">Coupon</span>
      </nav>
	   
	  
	   <div class="sl-pagebody">
	   <div class="sl-page-title">
	  <div class="row">
	  <div class="col-md-9">
	   <h5>Coupon List</h5>
	   </div>
	   <div class="col-md-3">
	    <a  class="btn btn-primary" data-toggle="modal" data-target="#cata">Add New</a>
		 <div id="cata" class="modal fade">
          <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content tx-size-sm">
              <div class="modal-header pd-x-20">
                <h6 class="tx-14 mg-b-0 tx-uppercase tx-inverse tx-bold">Add a Coupon</h6>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
			  <form action="<?php echo e(route('add.coupon')); ?>" method="post">
              <div class="modal-body pd-10">
			  <?php echo csrf_field(); ?>
			  
			  
			 <div class="from-group ">
		 <label for="">Coupon Name:</label>
		<input type="text" name="Coupon_Name" class="form-control" />

				<?php $__errorArgs = ['Coupon_Name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <strong class="text-danger"><?php echo e($message); ?></strong>
                   <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
					  </div>
										 
			  <div class="form-group mt-2">
			  
			  <label for="">Coupon Discount</label>
			  <input type="text" name="Coupon_Discount" class="form-control" />
			  <?php $__errorArgs = ['Coupon_Discount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <strong class="text-danger"><?php echo e($message); ?></strong>
                   <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			  
			  
			  </div>
			  
			  
			  
			  
			  
			  
              </div><!-- modal-body -->
              <div class="modal-footer">
               <input type="submit" class="btn btn-primary" value="ADD" />
				</form>
                <button type="button" class="btn btn-secondary pd-x-20" data-dismiss="modal">Close</button>
              </div>
            </div>
          </div><!-- modal-dialog -->
        </div><!-- modal -->
	   </div>
	   </div>
	   </div>
          
		  
		
      
	    <div class="card pd-20 pd-sm-40">
	    <div class="table-wrapper">
            <table id="datatable1" class="table table-striped">
              <thead>
                <tr>
                   <th class="col-md-2">Sl No.</th>
                 <th class="col-md-4">Coupon Name</th>
                 <th class="col-md-4">Coupon Discount</th>
                 <th class="col-md-2">Action</th>
                </tr>
              </thead>
			  <?php $__currentLoopData = $coupon; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			   <tbody>
			  <td><?php echo e($coupon->firstItem()+$loop->index); ?></td>
			  <td><?php echo e($data->Coupon_Name); ?></td>
			  <td><?php echo e($data->Coupon_Discount); ?></td>
			  
			  <td>
			  
			  <a  data-toggle="modal" data-target="#subedit<?php echo e($data->id); ?>"><i class="fa fa-edit" style="font-size:25px;"></i></a>
		<div id="subedit<?php echo e($data->id); ?>" class="modal fade">
          <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content tx-size-sm">
              <div class="modal-header pd-x-20">
                <h6 class="tx-14 mg-b-0 tx-uppercase tx-inverse tx-bold">Update Coupon</h6>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
			  <form action="<?php echo e(route('update_coupon')); ?>" method="post">
              <div class="modal-body pd-10">
			  <?php echo csrf_field(); ?>
			  <input type="hidden" name="id" value="<?php echo e($data->id); ?>" />
			  
			  <div class="form-group">
    <label for="exampleInputEmail1">Coupon Name</label>
    <input type="text" name="Coupon_Name" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" value="<?php echo e($data->Coupon_Name); ?>" >
 <?php $__errorArgs = ['Coupon_Name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                           <strong class="text-danger"><?php echo e($message); ?></strong>
                                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


 </div>
  
 
   <div class="form-group">
    <label for="exampleInputEmail1">Coupon Discount</label>
    <input type="text" name="Coupon_Discount" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" value="<?php echo e($data->Coupon_Discount); ?>">
 <?php $__errorArgs = ['Coupon_Discount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                           <strong class="text-danger"><?php echo e($message); ?></strong>
                                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


 </div>
					  
 
			  
			  
			  
			  
			  
			  
			  
              </div><!-- modal-body -->
              <div class="modal-footer">
               <input type="submit" class="btn btn-primary" value="UPDATE" />
				</form>
                <button type="button" class="btn btn-secondary pd-x-20" data-dismiss="modal">Close</button>
              </div>
            </div>
          </div><!-- modal-dialog -->
        </div><!-- modal -->
			  
			  
			  
   <a href="Coupon/delete/<?php echo e($data->id); ?>"><i class="fa fa-trash" aria-hidden="true" style="font-size:30px; color:red;"></i></a>
			  
			  
			  </td>
			  
			  
			  
			  
			  
			  
			  
			  
			  
			  
              </tbody>
			  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			  </table>
	           <?php echo e($coupon->links()); ?>

	  
	   
	   </div>
	   </div>
	  
	   
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  </div>
	     <?php echo $__env->make('admin.page.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\grocery_ecommerce\resources\views/admin/coupon.blade.php ENDPATH**/ ?>