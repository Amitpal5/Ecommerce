<?php echo $__env->make('admin.page.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <body>

    <!-- ########## START: LEFT PANEL ########## -->
   <?php echo $__env->make('admin.page.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <!-- ########## START: HEAD PANEL ########## -->
   <?php echo $__env->make('admin.page.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- ########## END: RIGHT PANEL ########## --->

    <!-- ########## START: MAIN PANEL ########## -->
	    <div class="sl-mainpanel">
         <nav class="breadcrumb sl-breadcrumb">
        <a class="breadcrumb-item" href="index.html">Dashboard</a>
        <span class="breadcrumb-item active">Product</span>
      </nav>
	   
	  
	   <div class="sl-pagebody">
	   <div class="sl-page-title">
	 
	    <div class="card pd-20 pd-sm-40">
          <h6 class="card-body-title">View Product</h6>
		 <div class="form-layout">
            <div class="row mg-b-25">
              <div class="col-lg-4">
			  <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="form-group">
                  <label class="form-control-label">Product Name<span class="tx-danger">*</span></label>
                <br><strong><?php echo e($data->product_name); ?></strong>
                </div>
              </div><!-- col-4 -->
              <div class="col-lg-4">
                <div class="form-group">
                  <label class="form-control-label">Product Code<span class="tx-danger">*</span></label>
                       <br>
					   <strong><?php echo e($data->product_code); ?></strong>

			   </div>
              </div><!-- col-4 -->
              <div class="col-lg-4">
                <div class="form-group">
                  <label class="form-control-label">Product Quantity<span class="tx-danger">*</span></label>
                <br><strong><?php echo e($data->product_qty); ?></strong>
                </div>
              </div><!-- col-4 -->
              
              <div class="col-lg-4">
                <div class="form-group mg-b-10-force">
                  <label class="form-control-label">Catagory<span class="tx-danger">*</span></label>
              
               
			  <br><strong><?php echo e($data->Cat_name); ?></strong>
                
                </div>
              </div><!-- col-4 -->
			  <div class="col-lg-4">
                <div class="form-group mg-b-10-force">
                  <label class="form-control-label">Sub Catagory<span class="tx-danger"></span></label>
                   <?php if($data->subcatagory_id ==NULL): ?>
				  <br /> <strong>No Sub Catagory</strong>
				  
                 <?php else: ?>
					 <br>
				 <?php $__currentLoopData = $product_sub; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				 <strong><?php echo e($data2->SubCatagory_name); ?></strong>
				 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				 <?php endif; ?>
					
				</div>
              </div><!-- col-4 -->
			  <div class="col-lg-4">
                <div class="form-group mg-b-10-force">
                  <label class="form-control-label">Brand<span class="tx-danger">*</span></label>
                   <?php $__currentLoopData = $productview; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			  <br><strong><?php echo e($data1->Brand_name); ?></strong>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                </div>
              </div><!-- col-4 -->
			  <div class="col-lg-4">
                <div class="form-group">
                  <label class="form-control-label">Product Size<span class="tx-danger">*</span></label>
                      <br><strong><?php echo e($data->product_size); ?></strong>
                </div>
              </div><!-- col-6 -->
			   <div class="col-lg-4">
                <div class="form-group">
                  <label class="form-control-label">Product Selling Price<span class="tx-danger">*</span></label>
                      <br><strong><?php echo e($data->price); ?></strong>
                </div>
              </div><!-- col-6 -->
			    <div class="col-lg-4">
                <div class="form-group">
                  <label class="form-control-label">Product Discount Price<span class="tx-danger"></span></label>
                      <br><strong><?php echo e($data->discount_price); ?></strong>
                </div>
              </div><!-- col-6 -->
			   
			  <div class="col-lg-12">
                <div class="form-group">
                  <label class="form-control-label">Product Details<span class="tx-danger">*</span></label>
                <textarea name="product_details" id="summernote" ><?php echo e($data->product_details); ?></textarea>
                </div>
              </div><!-- col-12 -->
			  
			 
			   
			  
		
			  
			   </div><!-- row -->
			   <hr />
			   <br />
			   <br />
			   <div class="row">
			   <div class="col-lg-4">
               <label class="">
			   <?php if($data->main_slider == 1): ?>
				    <span class="badge badge-success">Active</span>
			   
			   
			   <?php else: ?>
				  <span class="badge badge-danger">unactive</span>
				   
			   <?php endif; ?>
           <span>Main Slider</span>
         </label>
            </div>
			<div class="col-lg-4">
               <label class="">
             <?php if($data->hot_deal == 1): ?>
				    <span class="badge badge-success">Active</span>
			   
			   
			   <?php else: ?>
				  <span class="badge badge-danger">unactive</span>
				   
			   <?php endif; ?>
          <span>Hot Deal Product</span>
         </label>
            </div>
			<div class="col-lg-4">
               <label class="">
             <?php if($data->best_rated == 1): ?>
				    <span class="badge badge-success">Active</span>
			   
			   
			   <?php else: ?>
				  <span class="badge badge-danger">unactive</span>
				   
			   <?php endif; ?>
          <span>Best Rated Product</span>
         </label>
            </div>
			<div class="col-lg-4">
                <label class="">
             <?php if($data->mid_slider == 1): ?>
				    <span class="badge badge-success">Active</span>
			   
			   
			   <?php else: ?>
				  <span class="badge badge-danger">unactive</span>
				   
			   <?php endif; ?>
          <span>Mid Slider</span>
         </label>
            </div>
			<div class="col-lg-4">
                   <label class="">
             <?php if($data->hot_new == 1): ?>
				    <span class="badge badge-success">Active</span>
			   
			   
			   <?php else: ?>
				  <span class="badge badge-danger">unactive</span>
				   
			   <?php endif; ?>
          <span>Hot New Product</span>
         </label>
            </div>
			<div class="col-lg-4">
               <?php if($data->trend	== 1): ?>
				    <span class="badge badge-success">Active</span>
			   
			   
			   <?php else: ?>
				  <span class="badge badge-danger">unactive</span>
				   
			   <?php endif; ?>
          <span>Trend Product</span>
         </label>
            </div>
            </div>
            <br />
            <br />
            
          </div><!-- form-layout -->
        </div><!-- card -->
	  
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	  
	  
	  
	  
	  
	  
	  
	  </div>
	  </div>
	  </div>
	 </body>

 
 
 
 
	     <?php echo $__env->make('admin.page.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 <?php /**PATH C:\xampp\htdocs\grocery_ecommerce\resources\views/admin/viewproductbyid.blade.php ENDPATH**/ ?>