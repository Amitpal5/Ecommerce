<?php echo $__env->make('Frontend.page.anheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<style type="text/css">




.container {
    margin-top: 50px;
    margin-bottom: 50px
}

.card {
    position: relative;
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal;
    -ms-flex-direction: column;
    flex-direction: column;
    min-width: 0;
    word-wrap: break-word;
    background-color: #fff;
    background-clip: border-box;
    border: 1px solid rgba(0, 0, 0, 0.1);
    border-radius: 0.10rem
}

.card-header:first-child {
    border-radius: calc(0.37rem - 1px) calc(0.37rem - 1px) 0 0
}

.card-header {
    padding: 0.75rem 1.25rem;
    margin-bottom: 0;
    background-color: #fff;
    border-bottom: 1px solid rgba(0, 0, 0, 0.1)
}

.track {
    position: relative;
    background-color: #ddd;
    height: 7px;
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    margin-bottom: 60px;
    margin-top: 50px
}

.track .step {
    -webkit-box-flex: 1;
    -ms-flex-positive: 1;
    flex-grow: 1;
    width: 25%;
    margin-top: -18px;
    text-align: center;
    position: relative
}

.track .step.active:before {
    background: #FF5722
}

.track .step::before {
    height: 7px;
    position: absolute;
    content: "";
    width: 100%;
    left: 0;
    top: 18px
}

.track .step.active .icon {
    background: #ee5435;
    color: #fff
}

.track .icon {
    display: inline-block;
    width: 40px;
    height: 40px;
    line-height: 40px;
    position: relative;
    border-radius: 100%;
    background: #ddd
}

.track .step.active .text {
    font-weight: 400;
    color: #000
}

.track .text {
    display: block;
    margin-top: 7px
}

.itemside {
    position: relative;
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    width: 100%
}

.itemside .aside {
    position: relative;
    -ms-flex-negative: 0;
    flex-shrink: 0
}

.img-sm {
    width: 80px;
    height: 80px;
    padding: 7px
}

ul.row,
ul.row-sm {
    list-style: none;
    padding: 0
}

.itemside .info {
    padding-left: 15px;
    padding-right: 7px
}

.itemside .title {
    display: block;
    margin-bottom: 5px;
    color: #212529
}

p {
    margin-top: 0;
    margin-bottom: 1rem
}

.btn-warning {
    color: #ffffff;
    background-color: #ee5435;
    border-color: #ee5435;
    border-radius: 1px
}

.btn-warning:hover {
    color: #ffffff;
    background-color: #ff2b00;
    border-color: #ff2b00;
    border-radius: 1px
}












</style>


 <div class="breadcrumb-area bg-gray">
            <div class="container">
                <div class="breadcrumb-content text-center">
                    <ul>
                        <li>
                            <a href="<?php echo e(url('/')); ?>">Home</a>
                        </li>
                        <li class="active">order tracking Result</li>
                    </ul>
                </div>
            </div>
        </div>
        <!-- order tracking start -->
       <div class="container">
    <article class="card">
        <header class="card-header"> My Orders Tracking </header>
        <div class="card-body">
		
            <h6>Order ID: <?php echo e($order->order_id); ?></h6>
            <article class="card">
                <div class="card-body row">
				<?php if($order->Status == 0): ?>
                  <div class="col"> <strong>Status:</strong> <br> Pending</div>
			     <?php elseif($order->Status == 1): ?>
			     <div class="col"> <strong>Status:</strong> <br> Order Confirmed</div>
				  <?php elseif($order->Status == 2): ?>
			     <div class="col"> <strong>Status:</strong> <br> Hand Over Delivery Man</div>
				  <?php elseif($order->Status == 3): ?>
			     <div class="col"> <strong>Status:</strong> <br> Delivered</div>

			  
			    <?php else: ?>
		 <div class="col"> <strong>Status:</strong> <br> Cancle</div>
	 <?php endif; ?>

                  <div class="col"> <strong>Tracking #:</strong> <br> <?php echo e($order->order_id); ?> </div>
                </div>
				<br />
				<div class="progress">
				
				<?php if($order->Status == 0): ?>
	 <div class="progress-bar bg-danger" role="progressbar" style="width: 0%" aria-valuenow="15" aria-valuemin="0" aria-valuemax="100"></div>
      <?php elseif($order->Status == 1): ?>
	 <div class="progress-bar bg-danger" role="progressbar" style="width: 0%" aria-valuenow="15" aria-valuemin="0" aria-valuemax="100"></div>
     <div class="progress-bar bg-warning" role="progressbar" style="width: 30%" aria-valuenow="30" aria-valuemin="0" aria-valuemax="100"></div>
     <?php elseif($order->Status == 2): ?>
	 <div class="progress-bar bg-danger" role="progressbar" style="width: 0%" aria-valuenow="15" aria-valuemin="0" aria-valuemax="100"></div>
     <div class="progress-bar bg-warning" role="progressbar" style="width: 30%" aria-valuenow="30" aria-valuemin="0" aria-valuemax="100"></div>
	  <div class="progress-bar bg-info" role="progressbar" style="width: 30%" aria-valuenow="20" aria-valuemin="0" aria-valuemax="100"></div>
   <?php elseif($order->Status == 3): ?>
   <div class="progress-bar bg-danger" role="progressbar" style="width: 0%" aria-valuenow="15" aria-valuemin="0" aria-valuemax="100"></div>
     <div class="progress-bar bg-warning" role="progressbar" style="width: 30%" aria-valuenow="30" aria-valuemin="0" aria-valuemax="100"></div>
	  <div class="progress-bar bg-info" role="progressbar" style="width: 30%" aria-valuenow="20" aria-valuemin="0" aria-valuemax="100"></div>
     <div class="progress-bar bg-success" role="progressbar" style="width: 40%" aria-valuenow="20" aria-valuemin="0" aria-valuemax="100"></div>

   
   
	   <?php else: ?>
		   
				
				
<?php endif; ?>

</div>
<br />
<div class="container">
<?php if($order->Status == 0): ?>
<h4>Note:Your Order are review</h4>
<?php elseif($order->Status == 1): ?>
<h4>Note:Your Order are Accept</h4>
<?php elseif($order->Status == 2): ?>
<h4>Note:Your Order are Handover Delivery Man</h4>
<?php elseif($order->Status == 3): ?>
<h4>Note:Your Order are Succesfully Deliverd</h4>
<?php else: ?>
	<h4>Note:Your Order are Cancel</h4>

<?php endif; ?>
</div>
            
          
            <hr> <a href="#" class="btn btn-warning" data-abc="true"> <i class="fa fa-chevron-left"></i> Back to Shop Page</a>
        </div>
    </article>
</div>

<div class="container">


<h3>Order Details</h3>
<table class="table table-striped">
<tr>
<th>Payment Method</th>
<td><?php echo e($order->Payment_method); ?></td>

</tr>
<tr>
<th>Sub Total</th>
<td><?php echo e($order->sub_total); ?> TK</td>

</tr>
<tr>
<th>Shipping Charge</th>
<td><?php echo e($order->shipping_charge); ?></td>

</tr>
<tr>
<th>Total</th>
<td><?php echo e((int)$order->sub_total  + (int)$order->shipping_charge); ?> TK</td>

</tr>
<tr>
<th>Order Date</th>
<td><?php echo e($order->date); ?>-<?php echo e($order->month); ?>-<?php echo e($order->year); ?></td>

</tr>







</table>
</div>





















             <?php echo $__env->make('Frontend.page.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\grocery_ecommerce\resources\views/Frontend/usertracking_view.blade.php ENDPATH**/ ?>