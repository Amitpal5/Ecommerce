<?php echo $__env->make('admin.page.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <body>

    <!-- ########## START: LEFT PANEL ########## -->
   <?php echo $__env->make('admin.page.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <!-- ########## START: HEAD PANEL ########## -->
   <?php echo $__env->make('admin.page.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- ########## END: RIGHT PANEL ########## --->

    <!-- ########## START: MAIN PANEL ########## -->
	    <div class="sl-mainpanel">
         <nav class="breadcrumb sl-breadcrumb">
        <a class="breadcrumb-item" href="index.html">Dashboard</a>
        <span class="breadcrumb-item active">Year Delivery Order</span>
      </nav>
	   
	  
	   <div class="sl-pagebody">
	   <div class="sl-page-title">
	  <div class="row">
	  <div class="col-md-9">
	   <h5>Year Delivery  Order List</h5>
	   <h3 style="color:red">This Year Total Delivery <?php echo e($sub_total); ?> TK</h3>
	   </div>
	  
	   </div>
	   </div>
          
		  
		
      
	    <div class="card pd-20 pd-sm-40">
	    <div class="table-wrapper">
            <table id="datatable1" class="table table-striped">
              <thead>
                <tr>
                   <th class="col-md-2">Payment Method</th>
                 <th class="col-md-1">Sub Total</th>
                 <th class="col-md-1">Shipping</th>
                 <th class="col-md-2">Total</th>
                 <th class="col-md-2">Date</th>
                 <th class="col-md-2">Status</th>
                 <th class="col-md-2">Action</th>
                </tr>
              </thead>
			  <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			   <tbody>
			  

			  <td><?php echo e($value->Payment_method); ?></td>
			  <td><?php echo e($value->sub_total); ?></td>
			  <td><?php echo e($value->shipping_charge); ?></td>
			  <td><?php echo e((int)$value->sub_total + (int) $value->shipping_charge); ?> TK</td>
			  <td><?php echo e($value->date); ?>-<?php echo e($value->month); ?>-<?php echo e($value->year); ?></td>
			  <td><?php if($value->Status	== 0): ?>
			<span class="badge badge-warning">Pendding</span>
			<?php elseif($value->Status	== 1): ?>
			<span class="badge badge-info">Accept Order</span>
			<?php elseif($value->Status	== 2): ?>
			<span class="badge badge-info">Hand Over to Delivery boy</span>
			<?php elseif($value->Status	== 3): ?>
			<span class="badge badge-success">Delivered</span>

			
			
			
			<?php else: ?>
				<span class="badge badge-danger">Cancel</span>
			<?php endif; ?></td>
			  
              <td>
			  
			  	<a href="<?php echo e(route('admin.viewsucced.accept',['id'=>$value->id,'order_id' =>$value->order_id])); ?>"><i class="fa fa-edit" style="font-size:25px;"></i></a>

			  
			  
			  </td>
              </tbody>
			  	 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

			  </table>
 <?php echo e($orders->links()); ?>

	  
	   
	   </div>
	   </div>
	  
	   
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  </div>
	     <?php echo $__env->make('admin.page.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\grocery_ecommerce\resources\views/admin/report/search_report_year.blade.php ENDPATH**/ ?>