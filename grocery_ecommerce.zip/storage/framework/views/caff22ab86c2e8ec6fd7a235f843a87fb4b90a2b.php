<nav class="main_nav">
			<div class="container">
				<div class="row">
					<div class="col">
						
						<div class="main_nav_content d-flex flex-row">
                 <?php
				 
				 
				 $cata=DB::table('catagories')->get();
				 
				 
				 
				 
				 
				 
				 
				 ?>
							<!-- Categories Menu -->

							<div class="cat_menu_container">
								<div class="cat_menu_title d-flex flex-row align-items-center justify-content-start">
									<div class="cat_burger"><span></span><span></span><span></span></div>
									<div class="cat_menu_text">categories</div>
								</div>

								<ul class="cat_menu">
									<?php $__currentLoopData = $cata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<li class="hassubs">
										<a href="#"><?php echo e($value->Cat_name); ?><i class="fas fa-chevron-right"></i></a>
										<ul>
										<?php
										$sub=DB::table('sub_catagories')->where('Catagory_id',$value->id)->get();
										
										?>
										<?php $__currentLoopData = $sub; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<li class="hassubs">
												<a href="#"><?php echo e($data->SubCatagory_name); ?></i></a>
												
											</li>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</ul>
									</li>
																	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

								</ul>
							</div>

							<!-- Main Nav Menu -->

							<div class="main_nav_menu ml-4">
								<ul class="standard_dropdown main_nav_dropdown">
									<li><a href="<?php echo e(url('/')); ?>">Home<i class="fas fa-chevron-down"></i></a></li>
									
									
									
									<li><a href="#">Brand<i class="fas fa-chevron-down"></i></a></li>
									<li><a href="#">Contact<i class="fas fa-chevron-down"></i></a></li>
								</ul>
							</div>

							<!-- Menu Trigger -->

							<div class="menu_trigger_container ml-auto">
								<div class="menu_trigger d-flex flex-row align-items-center justify-content-end">
									<div class="menu_burger">
										<div class="menu_trigger_text">menu</div>
										<div class="cat_burger menu_burger_inner"><span></span><span></span><span></span></div>
									</div>
								</div>
							</div>

						</div>
					</div>
				</div>
			</div>
		</nav><?php /**PATH C:\xampp\htdocs\grocery_ecommerce\resources\views/Frontend/page/sidebar.blade.php ENDPATH**/ ?>