<?php echo $__env->make('admin.page.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <body>

    <!-- ########## START: LEFT PANEL ########## -->
   <?php echo $__env->make('admin.page.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <!-- ########## START: HEAD PANEL ########## -->
   <?php echo $__env->make('admin.page.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- ########## END: RIGHT PANEL ########## --->

    <!-- ########## START: MAIN PANEL ########## -->
	    <div class="sl-mainpanel">
         <nav class="breadcrumb sl-breadcrumb">
        <a class="breadcrumb-item" href="index.html">Dashboard</a>
        <span class="breadcrumb-item active">Product List</span>
      </nav>
	   
	  
	   <div class="sl-pagebody">
	   <div class="sl-page-title">
	  <div class="row">
	  <div class="col-md-9">
	   <h5>Product List</h5>
	   </div>
	   <div class="col-md-3">
	    <form class="form-inline" action="" method="get"  >

  <div class="form-group mx-sm-4 mb-2">
    <input type="text" name="search" class="form-control" placeholder="Search Product Name" required>
  </div>
 
</form>
	   </div>
	   </div>
	   </div>
          
		  
		
      
	    <div class="card pd-20 pd-sm-40">
	    <div class="table-wrapper">
            <table id="datatable1" class="table table-striped">
              <thead>
                <tr>
                   <th >Product Code</th>
                 <th>Product Name</th>
                 <th>Image</th>
                 <th>Catagory</th>
                 <th>Quantity</th>
                 <th>Status</th>
                 <th>Action</th>
                </tr>
              </thead>
			 <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			  <tbody>
			   
			  <tr>
			  <td><?php echo e($data->product_code); ?></td>
			  <td><?php echo e($data->product_name); ?></td>
			  <td><img src="<?php echo e($data->image_1); ?>" width="50px" height="50px" ></td>
			   <td><?php echo e($data->Cat_name); ?></td>
			   <td><?php echo e($data->product_qty); ?></td>
			   <td>
			   <?php if($data->status == 1): ?>
				   <span class="badge badge-success">Active</span>
			   
			   
			   <?php else: ?>
				  <span class="badge badge-danger">unactive</span>

			   
			   <?php endif; ?>
			   
			   
			   </td>
                <td>
		<a href="edit/product/<?php echo e($data->id); ?>"><i class="fa fa-edit" style="font-size:25px; "></i></a>
		<a href="view/product/<?php echo e($data->id); ?>"><i class="fa fa-eye" style="font-size:25px; "></i></a>
	
         <?php if($data->status==1): ?>
	<a href="inactive/product/<?php echo e($data->id); ?>"><i class="fa fa-arrow-down" style="font-size:25px; "></i></a>
 
		 <?php else: ?>
		<a href="active/product/<?php echo e($data->id); ?>"><i class="fa fa-arrow-up" style="font-size:25px; "></i></a>

		 <?php endif; ?>

        
		<a href="product/delete/<?php echo e($data->id); ?>"><i class="fa fa-trash" style="font-size:25px; color:red;"></i></a>

				
				</td>
			  
			  
			  </tr>
			  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			  
			  
			  
			  </tbody>
			  </table>
			   <?php echo e($product->links()); ?>


			  
	  
	   
	   </div>
	   </div>
	  
	   
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  </div>
	     <?php echo $__env->make('admin.page.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\grocery_ecommerce\resources\views/admin/show_product.blade.php ENDPATH**/ ?>