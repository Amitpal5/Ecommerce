<?php echo $__env->make('Frontend.page.anheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

 <div class="breadcrumb-area bg-gray" style="background-image:url('<?php echo e(asset('Image/back.jpg')); ?>')";>
            <div class="container">
                <div class="breadcrumb-content text-center" >
                    <ul>
                        <li>
                            <a href="<?php echo e(url('/')); ?>">Home</a>
                        </li>
                        <li class="active">Order Details</li>
                    </ul>
                </div>
            </div>
        </div>
		<div class="container" style="padding:20px;">
		
		<div class="row">
		<table class="table table-striped">
  <thead>
    <tr>
      <th scope="col">SL.No</th>
      <th scope="col">Product Name</th>
      <th scope="col">Product Qty</th>
      <th scope="col">Price</th>
      <th scope="col">Total Price</th>
    </tr>
  </thead>
  <tbody>
  <?php ($i=1); ?>
  <?php $__currentLoopData = $orderdet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <th scope="row"><?php echo e($i++); ?></th>
      <td><?php echo e($data->product_Name); ?></td>
      <td><?php echo e($data->Qty); ?></td>
      <td><?php echo e($data->Single_Price); ?></td>
      <td><?php echo e($data->Totla_price); ?></td>
    </tr>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
		
		
		
		
		
		
		
		
	
		
		
		
		
		
		</div>
		
		
		
		
		
		
		
		
		
		</div>
        <!-- my account wrapper start -->
      



























             <?php echo $__env->make('Frontend.page.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\grocery_ecommerce\resources\views/Frontend/userorder_details.blade.php ENDPATH**/ ?>