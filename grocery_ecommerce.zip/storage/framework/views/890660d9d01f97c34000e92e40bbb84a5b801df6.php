<?php echo $__env->make('Frontend.page.anheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="breadcrumb-area bg-gray" style="background-image:url('<?php echo e(asset('Image/back.jpg')); ?>');">
            <div class="container">
                <div class="breadcrumb-content text-center">
                    <ul>
                        <li>
                            <a href="<?php echo e(url('/')); ?>">Home</a>
                        </li>
                        <li class="active">Shop By Brand </li>
                    </ul>
                </div>
            </div>
        </div>
		
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
		 <div class="shop-area pt-120 pb-120">
		
           <div class="container">
		   <div class="row">
		   <?php $__currentLoopData = $brand_show; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		   <div class="col-lg-2 col-md-4 col-sm-4">
		   <a href="<?php echo e(url('/brand_page',$data2->id)); ?>"><img src="<?php echo e(('Image/').$data2->Brand_logo); ?>" alt="" /></a>
		   </div>
		   
		   
		   
		   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		   </div>
		   
		   
		   
		   
		   
		   
		   </div>
            </div>
        </div>
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>


<script type="text/javascript">


$(document).ready(function(){
$('.addcart').on('click',function(){

var id=$(this).data('id');
if(id){

$.ajax({
url:"<?php echo e(url('add/to/product')); ?>/"+id,
type:"GET",
dataType:"json",
 success:function(data) {
	
const Toast = Swal.mixin({
  toast: true,
  position: 'top-end',
  showConfirmButton: false,
  timer: 3000,
  timerProgressBar: true,
  didOpen: (toast) => {
    toast.addEventListener('mouseenter', Swal.stopTimer)
    toast.addEventListener('mouseleave', Swal.resumeTimer)
  }
})

if($.isEmptyObject(data.error)){
	
Toast.fire({
  icon: 'success',
  title: 'Succefully Added To Cart',
})	
	
	
}

else{
	Toast.fire({
  icon: 'error',
  title: 'data.error',
})	
	
	
}

},

});

}


});
});

</script>

























<?php echo $__env->make('Frontend.page.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\grocery_ecommerce\resources\views/Frontend/show_brand.blade.php ENDPATH**/ ?>