
    <script src="<?php echo e(asset('backend/lib/jquery/jquery.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/lib/popper.js/popper.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/lib/bootstrap/bootstrap.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/lib/jquery-ui/jquery-ui.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/lib/perfect-scrollbar/js/perfect-scrollbar.jquery.js')); ?>"></script>
	 
	 
	 <script src="<?php echo e(asset('backend/lib/highlightjs/highlight.pack.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/lib/datatables/jquery.dataTables.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/lib/datatables-responsive/dataTables.responsive.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/lib/select2/js/select2.min.js')); ?>"></script>
	
    <script src="<?php echo e(asset('backend/lib/jquery.sparkline.bower/jquery.sparkline.min.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/lib/d3/d3.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/lib/rickshaw/rickshaw.min.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/lib/chart.js/Chart.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/lib/Flot/jquery.flot.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/lib/Flot/jquery.flot.pie.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/lib/Flot/jquery.flot.resize.j')); ?>s"></script>
    <script src="<?php echo e(asset('backend/lib/flot-spline/jquery.flot.spline.js')); ?>"></script>
<script src="<?php echo e(asset('backend/lib/medium-editor/medium-editor.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/lib/summernote/summernote-bs4.min.js')); ?>"></script>

   
    <script>
      $(function(){
        'use strict';

        // Inline editor
        var editor = new MediumEditor('.editable');

        // Summernote editor
        $('#summernote').summernote({
          height: 150,
          tooltip: false
        })
      });
    </script>
    <script src="<?php echo e(asset('backend/js/starlight.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/js/ResizeSensor.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/js/dashboard.js')); ?>"></script>
	
	
	
       <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
<script>
  <?php if(Session::has('message')): ?>
  toastr.options =
  {
  	"closeButton" : true,
  	"progressBar" : true
  }
  		toastr.success("<?php echo e(session('message')); ?>");
  <?php endif; ?>

  <?php if(Session::has('error')): ?>
  toastr.options =
  {
  	"closeButton" : true,
  	"progressBar" : true
  }
  		toastr.error("<?php echo e(session('error')); ?>");
  <?php endif; ?>

  <?php if(Session::has('info')): ?>
  toastr.options =
  {
  	"closeButton" : true,
  	"progressBar" : true
  }
  		toastr.info("<?php echo e(session('info')); ?>");
  <?php endif; ?>

  <?php if(Session::has('warning')): ?>
  toastr.options =
  {
  	"closeButton" : true,
  	"progressBar" : true
  }
  		toastr.warning("<?php echo e(session('warning')); ?>");
  <?php endif; ?>
</script>
   
	

  </body>
</html><?php /**PATH C:\xampp\htdocs\grocery_ecommerce\resources\views/admin/page/footer.blade.php ENDPATH**/ ?>