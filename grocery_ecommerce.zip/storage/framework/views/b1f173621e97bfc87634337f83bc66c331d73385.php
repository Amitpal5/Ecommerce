<?php echo $__env->make('admin.page.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <body>

    <!-- ########## START: LEFT PANEL ########## -->
   <?php echo $__env->make('admin.page.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <!-- ########## START: HEAD PANEL ########## -->
   <?php echo $__env->make('admin.page.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- ########## END: RIGHT PANEL ########## --->

    <!-- ########## START: MAIN PANEL ########## -->
	    <div class="sl-mainpanel">
         <nav class="breadcrumb sl-breadcrumb">
        <a class="breadcrumb-item" href="index.html">Dashboard</a>
        <span class="breadcrumb-item active">Sub Catagory</span>
      </nav>
	   
	  
	   <div class="sl-pagebody">
	   <div class="sl-page-title">
	  <div class="row">
	  <div class="col-md-9">
	   <h5>Sub Catagory List</h5>
	   </div>
	   <div class="col-md-3">
	    <a  class="btn btn-primary" data-toggle="modal" data-target="#cata">Add New</a>
		 <div id="cata" class="modal fade">
          <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content tx-size-sm">
              <div class="modal-header pd-x-20">
                <h6 class="tx-14 mg-b-0 tx-uppercase tx-inverse tx-bold">Add a Sub Catagory</h6>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
			  <form action="<?php echo e(route('add.subcatagory')); ?>" method="post">
              <div class="modal-body pd-10">
			  <?php echo csrf_field(); ?>
			  
			  
			 <div class="from-group ">
		 <label for="">Catagory Name:</label>
		 <select name="cata_name" class="form-control <?php $__errorArgs = ['cat_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
			<option value="">Select Catagory Name</option>
			<?php $__currentLoopData = $cata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<option value="<?php echo e($data->id); ?>"><?php echo e($data->Cat_name); ?></option>
				 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</select>
				<?php $__errorArgs = ['cata_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <strong class="text-danger"><?php echo e($message); ?></strong>
                   <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
					  </div>
										 
			  <div class="form-group mt-2">
			  
			  <label for="">Sub Catagory Name</label>
			  <input type="text" name="SubCatagory_name" class="form-control" />
			  <?php $__errorArgs = ['SubCatagory_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <strong class="text-danger"><?php echo e($message); ?></strong>
                   <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			  
			  
			  </div>
			  
			  
			  
			  
			  
			  
              </div><!-- modal-body -->
              <div class="modal-footer">
               <input type="submit" class="btn btn-primary" value="ADD" />
				</form>
                <button type="button" class="btn btn-secondary pd-x-20" data-dismiss="modal">Close</button>
              </div>
            </div>
          </div><!-- modal-dialog -->
        </div><!-- modal -->
	   </div>
	   </div>
	   </div>
          
		  
		
      
	    <div class="card pd-20 pd-sm-40">
	    <div class="table-wrapper">
            <table id="datatable1" class="table table-striped">
              <thead>
                <tr>
                   <th class="col-md-2">Sl No.</th>
                 <th class="col-md-4">Catagory Name</th>
                 <th class="col-md-4">Sub Catagory Name</th>
                 <th class="col-md-2">Action</th>
                </tr>
              </thead>
			   <tbody>
			   <?php ($i=1); ?>
			   <?php $__currentLoopData = $sub; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($sub->firstItem()+$loop->index); ?></td>
                 <td><?php echo e($value->Cat_name); ?></td>
                 <td><?php echo e($value->SubCatagory_name); ?></td>
				 <td>
		<a  data-toggle="modal" data-target="#subedit<?php echo e($value->id); ?>"><i class="fa fa-edit" style="font-size:25px;"></i></a>
		<div id="subedit<?php echo e($value->id); ?>" class="modal fade">
          <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content tx-size-sm">
              <div class="modal-header pd-x-20">
                <h6 class="tx-14 mg-b-0 tx-uppercase tx-inverse tx-bold">Update Sub Catagory</h6>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
			  <form action="<?php echo e(route('update.subcatagory')); ?>" method="post">
              <div class="modal-body pd-10">
			  <?php echo csrf_field(); ?>
			  <input type="hidden" name="id" value="<?php echo e($value->id); ?>" />
			  
			  <div class="form-group">
    <label for="exampleInputEmail1">Previews Catagory Name</label>
    <input type="text" name="" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" value="<?php echo e($data->Cat_name); ?>">
 <?php $__errorArgs = ['Cat_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                           <strong class="text-danger"><?php echo e($message); ?></strong>
                                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


 </div>
   <div class="from-group mt-2">
	 <label for="">Catagory Name:</label>
		 <select name="cata_name" class="form-control">
		 <option value="">Select Catagory Name</option>
			<?php $__currentLoopData = $cata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			 <option value="<?php echo e($data->id); ?>"><?php echo e($data->Cat_name); ?></option>
			 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				 </select>
										 
				 </div>
 
   <div class="form-group">
    <label for="exampleInputEmail1">Sub Catagory Name</label>
    <input type="text" name="SubCatagory_name" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" value="<?php echo e($value->SubCatagory_name); ?>">
 <?php $__errorArgs = ['SubCatagory_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                           <strong class="text-danger"><?php echo e($message); ?></strong>
                                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


 </div>
					  
 
			  
			  
			  
			  
			  
			  
			  
              </div><!-- modal-body -->
              <div class="modal-footer">
               <input type="submit" class="btn btn-primary" value="UPDATE" />
				</form>
                <button type="button" class="btn btn-secondary pd-x-20" data-dismiss="modal">Close</button>
              </div>
            </div>
          </div><!-- modal-dialog -->
        </div><!-- modal -->
 
	<a href="subdelete/<?php echo e($value->id); ?>"><i class="fa fa-trash" aria-hidden="true" style="font-size:30px; color:red;"></i></a>
				 
				 </td>
                </tr>
                
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
			  </table>
	   <?php echo e($sub->links()); ?>


	  
	   
	   </div>
	   </div>
	  
	   
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  </div>
	     <?php echo $__env->make('admin.page.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\grocery_ecommerce\resources\views/admin/subcatagory.blade.php ENDPATH**/ ?>