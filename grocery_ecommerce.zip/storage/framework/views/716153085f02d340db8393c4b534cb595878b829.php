<!doctype html>
<html class="no-js" lang="en">


<!-- Mirrored from live.hasthemes.com/html/2/norda-preview/norda/index-3.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 09 Sep 2021 15:24:54 GMT -->
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
	
        <?php
			$data5=DB::table('sites')->first();

		?>


    <title><?php echo e($data5->site_title); ?></title>
    <meta name="robots" content="noindex, follow" />
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="assets/images/favicon.png">


    <!-- Use the minified version files listed below for better performance and remove the files listed above -->
    <link rel="stylesheet" href="<?php echo e(asset('frontend/css/vendor/vendor.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontend/css/plugins/plugins.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontend/css/style.min.css')); ?>">
	<link rel="stylesheet" href="sweetalert2.min.css">
	<link rel="stylesheet" type="text/css" 
     href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">


</head>

<body>

    <div class="main-wrapper">
        <header class="header-area">
            <div class="header-large-device">
                 <div class="header-top header-top-ptb-1 border-bottom-1">
                        <div class="row">
                            <div class="col-xl-4 col-lg-5">
                                <div class="header-offer-wrap">
                                    <p><i class="icon-paper-plane"></i> FREE SHIPPING Bangladesh wide for all orders over <span>3000 TK</span></p>
                                </div>
                            </div>
                            <div class="col-xl-8 col-lg-7">
                                <div class="header-top-right">
								
								
								<?php if(Route::has('login')): ?>
                                   <?php if(auth()->guard()->check()): ?>
							   
								
								
								
                                    <div class="same-style-wrap" style="margin-right:100px;">
                                        
                                        <div class="same-style same-style-border language-wrap">
										 <a href="<?php echo e(url('/order')); ?>" class="mr-3">Order Tracking</i></a> 

                                            <a class="language-dropdown-active" href="#">My Account <i class="icon-arrow-down"></i></a>
                                            <div class="language-dropdown">
                                                <ul>
                                                    <li><a href="<?php echo e(url('/user_dashboard')); ?>">Profile</a></li>

                                                     
                                                </ul>
                                            </div>
                                        </div>
                                      
                                    </div>
                                     <?php else: ?>
										<div class="col-xl-5 col-lg-5" style="margin-right:100px;">
                                <div class="header-top-right">
                                    <div class="same-style-wrap">
                                        <a href="<?php echo e(url('/order')); ?>" class="mr-3">Order Tracking</i></a> 
                                       <a href="<?php echo e(url('/login')); ?>"><i class="icon-user">Login</i></a> 
                                       <a href="<?php echo e(url('/register')); ?>" class="ml-2"><i class="icon-user">Register</i></a> 
                                       
                                    </div>
                                </div>
                            </div>
							   <?php endif; ?>
								<?php endif; ?> 
									 
									 
									 
                                </div>
                            </div>
                        </div>
                    </div>
                <div class="header-middle header-middle-padding-1">
                    <div class="container">
                        <div class="row align-items-center">
                            <div class="col-xl-2 col-lg-2">
                                <div class="logo">
                                    <a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('Image/amit.png')); ?>" alt="logo"></a>
                                </div>
                            </div>
							<?php
					
					$cata=DB::table('catagories')->get();
					
					
					?>
                            <div class="col-xl-7 col-lg-7">
                                <div class="categori-search-wrap">
                                    <div class="categori-style-1">
                                        <select class="nice-select nice-select-style-1">
                                            <option>All Categories </option>
											  <?php $__currentLoopData = $cata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option><?php echo e($data->Cat_name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="search-wrap-3">
                                        <form action="<?php echo e(route('serachproductajax')); ?>" method="post" id="serach_from">
										<?php echo csrf_field(); ?>
                                            <input placeholder="Search Products..." name="search"  type="text">
                                            <button type="submit" name="submit"><i class="lnr lnr-magnifier"></i></button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-3">
                                <div class="header-action header-action-flex">
                                   
                                   
                                    <div class="same-style-2 same-style-2-font-inc header-cart">
                                        <a class="cart-active" href="#">
                                           <i class="icon-basket-loaded"></i>
                                           <span class="pro-count green" id="total_cart_item"><?php echo e(Cart::count()); ?></span>

                                            <span class="cart-amount id="cart_amount"><?php echo e(Cart::subtotal()); ?>TK</span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="header-bottom">
                    <div class="container">
                        <div class="row align-items-center">
                            <div class="col-lg-3">
                                <div class="main-categori-wrap">
								<?php
					
					$cata=DB::table('catagories')->get();
					
					
					?>
                                    <a class="categori-show" href="#"><i class="lnr lnr-menu"></i> All Department <i class="icon-arrow-down icon-right"></i></a>
                                    <div class="category-menu categori-hide">
                                        <nav>
                                            <ul>
                                               
                                                       
                                                         <?php $__currentLoopData = $cata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
														 
                                                <li class="cr-dropdown"><a href="<?php echo e(url('/catagory_product',$data->id)); ?>"> <?php echo e($data->Cat_name); ?><span class="icon-arrow-right"></span></a>
                                                    <?php

                                                          $sub=DB::table('sub_catagories')->where('Catagory_id',$data->id)->get();

                                                           ?>	
                                                    
													
													<?php $__currentLoopData = $sub; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>	
												<?php if($fa->SubCatagory_name==NULL): ?>
													
												<?php else: ?>		

													<div class="category-menu-dropdown ct-menu-res-height-2">
                                                        <div class="single-category-menu">
                                                        <?php $__currentLoopData = $sub; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                     									
                                                            <ul>
															
                                                                <li><a href="<?php echo e(url('/subcatagory_product',$res->id)); ?>"><?php echo e($res->SubCatagory_name); ?></a></li>
                                                               
                                                           	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
														   </ul>
														  
															
                                                        </div>
														
 
                                                    </div>
													  <?php endif; ?>
                                                   	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

													
														
													
													
                                                </li>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                
                                            </ul>
                                        </nav>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="main-menu main-menu-padding-1 main-menu-font-size-14 main-menu-lh-2">
                                    <nav>
                                        <ul>
                                            
                                            
                                            
                                            <li><a href="<?php echo e(url('/')); ?>">Home </a></li>
                                            <li><a href="<?php echo e(url('/shop_page')); ?>">Shop </a></li>
                                            <li><a href="<?php echo e(url('/frontend_brand')); ?>">Brand </a></li>
                                            <li><a href="<?php echo e(url('/contact')); ?>">Contact </a></li>
                                        </ul>
                                    </nav>
                                </div>
                            </div>
                            <div class="col-lg-3">
                                <div class="hotline">
                                    <p><i class="icon-call-end"></i> <span>Hotline</span><?php echo e($data5->hotline); ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="header-small-device small-device-ptb-1">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-5">
                            <div class="mobile-logo">
                                <a href="<?php echo e(url('/')); ?>">
                                    <img alt="" src="<?php echo e(asset('Image/amit.png')); ?>">
                                </a>
                            </div>
                        </div>
                        <div class="col-7">
                            <div class="header-action header-action-flex">
							
							<?php if(Route::has('login')): ?>
                                   <?php if(auth()->guard()->check()): ?>
							 
							 
							
							
							<?php else: ?>
							 <a href="<?php echo e(url('/login')); ?>"><i class="icon-user">Login</i></a> 
                                       <a href="<?php echo e(url('/register')); ?>" class="ml-2"><i class="icon-user">Register</i></a> 
							
							<?php endif; ?>
							<?php endif; ?>
							
                                
                              
                                <div class="same-style-2 same-style-2-font-inc header-cart">
                                    <a class="cart-active" href="#">
                                        <i class="icon-basket-loaded"></i><span class="pro-count green" id="total_cart_item"><?php echo e(Cart::count()); ?></span>
							        <span class="cart-amount id="cart_amount"><?php echo e(Cart::subtotal()); ?>TK</span>

                                    </a>
                                </div>
                                <div class="same-style-2 main-menu-icon">
                                    <a class="mobile-header-button-active" href="#"><i class="icon-menu"></i> </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <!-- mini cart start -->
		
		
		
		
		
		
		
		
		
		
		
        <div class="sidebar-cart-active" id="cart">
            
        </div>
        <!-- mobile header start -->
        <div class="mobile-header-active mobile-header-wrapper-style">
            <div class="clickalbe-sidebar-wrap">
                <a class="sidebar-close"><i class="icon_close"></i></a>
                <div class="mobile-header-content-area">
                   
                    <div class="mobile-search mobile-header-padding-border-1">
                        <form class="search-form" action="#">
                            <input type="text" placeholder="Search here…">
                            <button class="button-search"><i class="icon-magnifier"></i></button>
                        </form>
                    </div>
                    <div class="mobile-menu-wrap mobile-header-padding-border-2">
                        <!-- mobile menu start -->
                        <nav>
                            <ul class="mobile-menu">
                                
                               
                                <li><a href="<?php echo e(asset(url('/'))); ?>">Home</a></li>
								<li><a href="<?php echo e(url('/shop_page')); ?>">Shop </a></li>
                                <li><a href="<?php echo e(url('/frontend_brand')); ?>">Brand</a></li>
                                <li><a href="<?php echo e(url('/contact')); ?>">Contact us</a></li>
							    <li><a href="<?php echo e(url('/order')); ?>" class="mr-3">Order Tracking</i></a></li> 

								<?php if(Route::has('login')): ?>
                                   <?php if(auth()->guard()->check()): ?>
							   
						 <li><a href="<?php echo e(url('/user_dashboard')); ?>">My Account</a></li>
						 <?php else: ?>
							 <?php endif; ?>
						 <?php endif; ?>

                            </ul>
                        </nav>
                        <!-- mobile menu end -->
                    </div>
					
					 
					
					
					
					
                    <div class="main-categori-wrap mobile-menu-wrap mobile-header-padding-border-3">
					<?php
					
					$cata=DB::table('catagories')->get();
					
					
					?>
                        <a class="categori-show" href="#">
                            <i class="lnr lnr-menu"></i> All Department <i class="icon-arrow-down icon-right"></i>
                        </a>
                        <div class="categori-hide-2">
                            <nav>
                                <ul class="mobile-menu">
                                 <?php $__currentLoopData = $cata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                              
			  <li class="menu-item-has-children"><a href="<?php echo e(url('/catagory_product',$data->id)); ?>"><?php echo e($data->Cat_name); ?></a>
			                            <?php

                                                          $sub=DB::table('sub_catagories')->where('Catagory_id',$data->id)->get();

                                                           ?>	
                                                    <?php $__currentLoopData = $sub; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <ul class="dropdown">
                                                    <li><a href="<?php echo e(url('/subcatagory_product',$res->id)); ?>"><?php echo e($res->SubCatagory_name); ?></a></li>
                                                    
                                                </ul>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            </li>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </li>
                                </ul>
								
                            </nav>
                        </div>
                    </div>
					
					 
                  
                    <div class="mobile-contact-info mobile-header-padding-border-4">
                        <ul>
                            <li><i class="icon-phone "></i> <?php echo e($data5->hotline); ?></li>
                            <li><i class="icon-envelope-open "></i> <?php echo e($data5->email); ?></li>
                            <li><i class="icon-home"></i> <?php echo e($data5->address); ?></li>
                        </ul>
                    </div>
                    <div class="mobile-social-icon">
                        <a class="facebook" href="#"><i class="icon-social-facebook"></i></a>
                        <a class="twitter" href="#"><i class="icon-social-twitter"></i></a>
                        <a class="pinterest" href="#"><i class="icon-social-pinterest"></i></a>
                        <a class="instagram" href="#"><i class="icon-social-instagram"></i></a>
                    </div>
                </div>
            </div>
        </div><?php /**PATH C:\xampp\htdocs\grocery_ecommerce\resources\views/Frontend/page/header.blade.php ENDPATH**/ ?>