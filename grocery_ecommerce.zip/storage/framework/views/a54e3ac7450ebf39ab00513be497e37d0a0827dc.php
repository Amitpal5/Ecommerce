<div class="sidebar-cart-all">
    <a class="cart-close" href="#"><i class="icon_close"></i></a>
    <div class="cart-content">
        <h3>Shopping Cart</h3>
		<?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <ul>
		
            <li class="single-product-cart">
               
				
                <div class="cart-title">
                    <h4><a href="#"></a><?php echo e($data->name); ?></h4>
                    <span><?php echo e($data->price); ?> TK</span>
                    qty:<span><?php echo e($data->qty); ?></span>
                </div>
                <div class="cart-delete">
                    	  <a href="<?php echo e(url('remove/cart/'.$data->rowId)); ?>"><i class="icon-close" style="font-size:20px;"></i></a>

                </div>
            </li>
           
        </ul>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div class="cart-total">
            <h4>Subtotal: <span><?php echo e(Cart::subtotal()); ?></span></h4>
        </div>
        <div class="cart-checkout-btn">
            <a class="btn-hover cart-btn-style" href="<?php echo e(route('user.cart')); ?>">view cart</a>
            <a class="no-mrg btn-hover cart-btn-style" href="<?php echo e(route('user.checkout')); ?>">checkout</a>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\grocery_ecommerce\resources\views/Frontend/cart/cart_data.blade.php ENDPATH**/ ?>